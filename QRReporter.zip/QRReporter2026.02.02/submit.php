<?php
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

require_once __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PhpOffice\PhpSpreadsheet\IOFactory;

function error_exit($msg) {
  echo "<div style='margin:auto;max-width:480px;background:#fff;padding:2em 1em 2em 1em;color:#c80c16;
  border-radius:10px;font-size:1.1em;text-align:center'>Hiba: $msg<br><br>
  <a href='report.html'>Vissza a hibabejelentéshez</a></div>";
  exit();
}

$fields = ['reporter','contact','company','description'];
foreach ($fields as $fld) {
  if (empty($_POST[$fld])) error_exit("A(z) <b>{$fld}</b> mező hiányzik!");
}

if (!isset($_FILES['picture']) || $_FILES['picture']['error'] !== UPLOAD_ERR_OK || $_FILES['picture']['size'] == 0) {
  error_exit('Nem töltöttél fel érvényes képet.');
}
if ($_FILES['picture']['size'] > 25*1024*1024) {
  error_exit('A kép mérete túl nagy (max. 25 MB).');
}
$ext = strtolower(pathinfo($_FILES['picture']['name'], PATHINFO_EXTENSION));
$allowed = ['jpg','jpeg','png','gif','webp','bmp'];
if (!in_array($ext, $allowed)) error_exit('Csak kép fájl tölthető fel (jpg, png, stb.)');
if (!is_dir("uploads")) mkdir("uploads");
$fname = uniqid("img_", true).".".$ext;
$target_file = "uploads/".$fname;
if (!move_uploaded_file($_FILES['picture']['tmp_name'], $target_file)) {
  error_exit("Nem sikerült menteni a képet.");
}

$id = isset($_POST['id']) ? trim($_POST['id']) : '';
$projekt = '';
$eszkoz = '';
$gyurutipus = '';
$gyurukszama = '';
if ($id !== '') {
  try {
    $spreadsheet = IOFactory::load('DeviceDatabase.xlsx');
    $worksheet = $spreadsheet->getActiveSheet();
    foreach ($worksheet->getRowIterator() as $i => $row) {
      if ($i == 1) continue;
      $cells = [];
      foreach ($row->getCellIterator() as $cell) $cells[] = (string)$cell->getValue();
      if (trim($cells[0]) === $id) {
        $projekt = $cells[1] ?? '';
        $eszkoz = $cells[2] ?? '';
        $gyurutipus = $cells[3] ?? '';
        $gyurukszama = $cells[4] ?? '';
        break;
      }
    }
  } catch(Exception $e) { }
}
if ($projekt === '' && $eszkoz === '') {
  error_exit("Nem található ilyen azonosító az adatbázisban!");
}

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'sender@gmail.com';
    $mail->Password = 'password';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;;
    $mail->Port = 587;
    $mail->CharSet = 'UTF-8';
    $mail->setFrom('sender@gmail.com', 'Hibabejelentő');
    $mail->addAddress('address@domain.hu');
    $mail->Subject = 'Hibabejelentés';
    
    $body = "
<b>Hibabejelentő neve:</b> ".htmlspecialchars($_POST['reporter'])."<br>
<b>Elérhetőség:</b> ".htmlspecialchars($_POST['contact'])."<br>
<b>Cég neve:</b> ".htmlspecialchars($_POST['company'])."<br>
<b>Projekt neve:</b> ".htmlspecialchars($projekt)."<br>
<b>Eszköz típusa:</b> ".htmlspecialchars($eszkoz)."<br>
<b>Gyűrű kártyák típusa:</b> ".htmlspecialchars($gyurutipus)."<br>
<b>Gyűrű kártyák száma:</b> ".htmlspecialchars($gyurukszama)."<br>
<b>Beküldés ideje:</b> ".date("Y-m-d H:i:s")."<br>
<b>Hiba leírása:</b><br>".nl2br(htmlspecialchars($_POST['description']))."
    ";

    $mail->isHTML(true);
    $mail->Body = $body;
    $mail->addAttachment($target_file);

    $mail->send();
    unlink($target_file);
    echo "Sikeres hibabejelentés! Hamarosan keresni fogjuk.";
    exit;

} catch(Exception $e) {
    @unlink($target_file);
    error_exit("Nem sikerült elküldeni az emailt: " . $mail->ErrorInfo);
}
?>
