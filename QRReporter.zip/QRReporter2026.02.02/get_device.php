<?php

require_once __DIR__ . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['id']) || trim($_GET['id']) === "") {
    http_response_code(400);
    echo json_encode(['error' => 'ID paraméter hiányzik!']);
    exit;
}

$id = trim($_GET['id']);
$data = null;
try {
    $spreadsheet = IOFactory::load('DeviceDatabase.xlsx');
    $worksheet = $spreadsheet->getActiveSheet();
    foreach ($worksheet->getRowIterator() as $i => $row) {
        if ($i == 1) continue;
        $cells = [];
        foreach ($row->getCellIterator() as $cell) $cells[] = (string)$cell->getValue();
        if (trim($cells[0]) === $id) {
            $data = [
                'id'        => $cells[0] ?? '',
                'project'   => $cells[1] ?? '',
                'device'    => $cells[2] ?? '',
                'ringtype'  => $cells[3] ?? '',
                'ringcount' => $cells[4] ?? ''
            ];
            break;
        }
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Excel olvasási hiba.']);
    exit;
}

if ($data) {
    echo json_encode($data);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Nem található ilyen azonosító az adatbázisban!']);
}
